"""
Simple command-line prediction utility.
"""
from pathlib import Path
import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "04_Model" / "student_model.pkl"

FEATURES = [
    "attendance", "study_hours", "previous_marks",
    "assignment_score", "internal_marks"
]

def predict_performance(attendance, study_hours, previous_marks,
                        assignment_score, internal_marks):
    model = joblib.load(MODEL_PATH)
    data = pd.DataFrame([{
        "attendance": attendance,
        "study_hours": study_hours,
        "previous_marks": previous_marks,
        "assignment_score": assignment_score,
        "internal_marks": internal_marks,
    }])
    prediction = model.predict(data)[0]
    probability = None
    if hasattr(model, "predict_proba"):
        probability = float(max(model.predict_proba(data)[0]))
    return prediction, probability

if __name__ == "__main__":
    result, probability = predict_performance(85, 6, 72, 80, 75)
    print("Prediction:", result)
    if probability is not None:
        print(f"Model confidence: {probability*100:.2f}%")
