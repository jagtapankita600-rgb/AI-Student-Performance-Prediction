"""
Evaluate the saved model and generate result files/graphs.
"""
from pathlib import Path
import json
import joblib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report
)

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "01_Dataset" / "processed" / "student_data_clean.csv"
MODEL_PATH = BASE_DIR / "04_Model" / "student_model.pkl"
RESULTS_DIR = BASE_DIR / "06_Results"
GRAPH_DIR = RESULTS_DIR / "graphs"
GRAPH_DIR.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "attendance", "study_hours", "previous_marks",
    "assignment_score", "internal_marks"
]

def main():
    df = pd.read_csv(DATA_PATH)
    X = df[FEATURES]
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    model = joblib.load(MODEL_PATH)
    pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, pred)
    report = classification_report(y_test, pred, output_dict=True)
    cm = confusion_matrix(y_test, pred, labels=["Fail", "Pass"])

    (RESULTS_DIR / "evaluation.json").write_text(
        json.dumps({
            "accuracy_percent": round(accuracy * 100, 2),
            "classification_report": report,
        }, indent=2),
        encoding="utf-8"
    )

    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Fail", "Pass"], yticklabels=["Fail", "Pass"]
    )
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    if hasattr(model, "feature_importances_"):
        importance = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
        importance.plot(kind="barh")
        plt.xlabel("Importance")
        plt.title("Feature Importance")
        plt.tight_layout()
        plt.savefig(GRAPH_DIR / "feature_importance.png", dpi=150)
        plt.close()

    print(f"Accuracy: {accuracy*100:.2f}%")
    print(classification_report(y_test, pred))

if __name__ == "__main__":
    main()
