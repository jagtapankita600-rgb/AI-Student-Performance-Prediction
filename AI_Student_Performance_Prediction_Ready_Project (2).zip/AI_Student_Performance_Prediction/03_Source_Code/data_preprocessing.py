"""
Data preprocessing utilities for AI-Based Student Performance Prediction.
"""
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]
RAW_PATH = BASE_DIR / "01_Dataset" / "raw" / "student_data.csv"
PROCESSED_PATH = BASE_DIR / "01_Dataset" / "processed" / "student_data_clean.csv"

FEATURES = [
    "attendance",
    "study_hours",
    "previous_marks",
    "assignment_score",
    "internal_marks",
]
TARGET = "result"

def load_and_clean_data():
    df = pd.read_csv(RAW_PATH)
    df = df.drop_duplicates().copy()

    for col in FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df[TARGET] = df[TARGET].astype(str).str.strip().str.title()
    df = df.dropna(subset=FEATURES + [TARGET])

    df = df[
        (df["attendance"].between(0, 100)) &
        (df["study_hours"] >= 0) &
        (df["previous_marks"].between(0, 100)) &
        (df["assignment_score"].between(0, 100)) &
        (df["internal_marks"].between(0, 100)) &
        (df[TARGET].isin(["Pass", "Fail"]))
    ].copy()

    PROCESSED_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(PROCESSED_PATH, index=False)
    return df

if __name__ == "__main__":
    cleaned = load_and_clean_data()
    print(f"Cleaned dataset saved to: {PROCESSED_PATH}")
    print(f"Rows: {len(cleaned)}")
