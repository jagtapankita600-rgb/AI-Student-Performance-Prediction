"""
Train Decision Tree and Random Forest models and save the better model.
"""
from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "01_Dataset" / "processed" / "student_data_clean.csv"
MODEL_DIR = BASE_DIR / "04_Model"
RESULTS_DIR = BASE_DIR / "06_Results"
MODEL_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

FEATURES = [
    "attendance",
    "study_hours",
    "previous_marks",
    "assignment_score",
    "internal_marks",
]
TARGET = "result"

def main():
    if not DATA_PATH.exists():
        from data_preprocessing import load_and_clean_data
        df = load_and_clean_data()
    else:
        df = pd.read_csv(DATA_PATH)

    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    models = {
        "Decision Tree": DecisionTreeClassifier(
            max_depth=5, min_samples_leaf=4, random_state=42
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=8, min_samples_leaf=2,
            random_state=42, n_jobs=-1
        ),
    }

    scores = {}
    reports = {}

    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        scores[name] = round(accuracy_score(y_test, pred) * 100, 2)
        reports[name] = classification_report(y_test, pred, output_dict=True)

    best_name = max(scores, key=scores.get)
    best_model = models[best_name]
    joblib.dump(best_model, MODEL_DIR / "student_model.pkl")

    metrics = {
        "best_model": best_name,
        "accuracies_percent": scores,
        "classification_reports": reports,
        "features": FEATURES,
    }
    (RESULTS_DIR / "metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )

    print("Training complete.")
    print("Accuracies:", scores)
    print("Best model:", best_name)
    print("Saved:", MODEL_DIR / "student_model.pkl")

if __name__ == "__main__":
    main()
