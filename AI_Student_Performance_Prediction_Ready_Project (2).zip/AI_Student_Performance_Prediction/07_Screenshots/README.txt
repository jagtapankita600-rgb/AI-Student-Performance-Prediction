Save screenshots of the dataset, model results, and Streamlit app here.
