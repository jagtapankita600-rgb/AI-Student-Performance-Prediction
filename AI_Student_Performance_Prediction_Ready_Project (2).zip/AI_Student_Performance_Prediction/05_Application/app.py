import sys
from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "04_Model" / "student_model.pkl"

st.set_page_config(
    page_title="AI Student Performance Predictor",
    page_icon="🎓",
    layout="centered",
)

st.title("🎓 AI-Based Student Performance Prediction")
st.write("Enter student academic information to predict the expected result.")

if not MODEL_PATH.exists():
    st.error(
        "Trained model not found. Run "
        "`python 03_Source_Code/train_model.py` first."
    )
    st.stop()

model = joblib.load(MODEL_PATH)

st.subheader("Student Information")

attendance = st.slider("Attendance (%)", 0, 100, 75)
study_hours = st.slider("Study Hours per Day", 0.0, 12.0, 5.0, 0.5)
previous_marks = st.slider("Previous Marks (%)", 0, 100, 60)
assignment_score = st.slider("Assignment Score (%)", 0, 100, 70)
internal_marks = st.slider("Internal Marks (%)", 0, 100, 65)

if st.button("🔮 Predict Performance", use_container_width=True):
    data = pd.DataFrame([{
        "attendance": attendance,
        "study_hours": study_hours,
        "previous_marks": previous_marks,
        "assignment_score": assignment_score,
        "internal_marks": internal_marks,
    }])

    prediction = model.predict(data)[0]

    st.divider()
    if prediction == "Pass":
        st.success("### Prediction: PASS")
        st.write("The model predicts that the student is likely to pass.")
    else:
        st.warning("### Prediction: FAIL")
        st.write("The model predicts that the student may need additional academic support.")

    if hasattr(model, "predict_proba"):
        confidence = max(model.predict_proba(data)[0]) * 100
        st.metric("Model Confidence", f"{confidence:.2f}%")

    if hasattr(model, "feature_importances_"):
        importance = pd.Series(
            model.feature_importances_,
            index=data.columns
        ).sort_values(ascending=False)

        st.subheader("Important Factors")
        st.bar_chart(importance)
