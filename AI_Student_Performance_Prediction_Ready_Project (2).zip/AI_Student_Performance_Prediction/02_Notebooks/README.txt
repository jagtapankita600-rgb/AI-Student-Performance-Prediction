Use this folder for optional Jupyter/Colab notebooks. The runnable Python workflow is in 03_Source_Code.
