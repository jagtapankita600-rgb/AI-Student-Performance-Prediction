# AI-Based Student Performance Prediction

A small machine-learning project that predicts student performance as **Pass** or **Fail** using attendance, study hours, previous marks, assignment score, and internal marks.

## Technology
- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn
- Joblib
- Streamlit

## Machine Learning Models
- Decision Tree Classifier
- Random Forest Classifier

The training script compares both models and saves the better-performing model as `04_Model/student_model.pkl`.

## Project Structure

```text
AI_Student_Performance_Prediction/
├── 01_Dataset/
├── 02_Notebooks/
├── 03_Source_Code/
├── 04_Model/
├── 05_Application/
├── 06_Results/
├── 07_Screenshots/
├── 08_Documentation/
├── 09_Testing/
├── README.md
├── requirements.txt
└── .gitignore
```

## How to Run

### 1. Open terminal in the project folder

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Clean the dataset

```bash
python 03_Source_Code/data_preprocessing.py
```

### 4. Train the models

```bash
python 03_Source_Code/train_model.py
```

### 5. Evaluate the saved model

```bash
python 03_Source_Code/evaluate_model.py
```

### 6. Start the web application

```bash
streamlit run 05_Application/app.py
```

## Important Note

The included CSV is a **synthetic educational dataset** created for demonstration. Do not represent it as real student records. For a stronger academic project, replace it with an appropriately sourced public dataset or institutionally approved anonymized data.

## Expected Output

The Streamlit application accepts student details and predicts:
- PASS
- FAIL

It also displays model confidence and feature importance when supported by the trained model.
